// types/models.ts
export interface ModelDescriptor {
  value: string;
  label: string;
  description?: string;
}